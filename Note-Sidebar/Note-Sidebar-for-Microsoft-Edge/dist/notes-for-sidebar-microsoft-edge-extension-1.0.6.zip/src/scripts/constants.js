/* eslint-disable no-unused-vars */
const exbrowser = "edge";
// values: "chrome", "safari", "edge", "firefox", "opera", "yandex", "whale"
const linkredirectionoptions = "https://www.stefanvd.net/project/note-sidebar/browser/options/";
const linkdeveloperwebsite = "https://www.stefanvd.net";
const linkproduct = "https://microsoftedge.microsoft.com/addons/detail/" + chrome.runtime.id;
const linkdonate = "https://www.stefanvd.net/donate/";
const writereview = "https://microsoftedge.microsoft.com/addons/detail/" + chrome.runtime.id + "/reviews";
const linkchangelog = "https://www.stefanvd.net/project/note-sidebar/browser/microsoft-edge/changelog/";
const linktranslate = "https://www.stefanvd.net/project/translate/";
const linksupport = "https://www.stefanvd.net/support/";
const linkwelcome = "https://www.stefanvd.net/project/note-sidebar/browser/microsoft-edge/welcome/";
const linkuninstall = "https://www.stefanvd.net/project/note-sidebar/browser/microsoft-edge/uninstall/";
const linkguide = "https://www.stefanvd.net/project/note-sidebar/browser/microsoft-edge/guide/";
const linkproductdescription = "https://www.stefanvd.net/project/note-sidebar/browser-extension/";
const browsernewtab = "edge://newtab/";
const browserstore = "https://microsoftedge.microsoft.com";
const linkyoutube = "https://www.youtube.com/@stefanvandamme?sub_confirmation=1";
const devmode = true;
const devdonate = false;