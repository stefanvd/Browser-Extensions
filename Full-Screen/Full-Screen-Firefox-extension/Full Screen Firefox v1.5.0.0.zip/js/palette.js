//================================================
/*

Full Screen
Go full screen with one click on the button.
Copyright (C) 2020 Stefan vd
www.stefanvd.net

This program is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 2
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.


To view a copy of this license, visit http://creativecommons.org/licenses/GPL/2.0/

*/
//================================================

function $(id) { return document.getElementById(id); }

var darkmode; var firstDate; var optionskipremember; var firstsawrate; var fullscreenweb; var fullscreenwindow; var fullscreenvideo; var videoinwindow; var videooutwindow;

function save_options(){
	chrome.storage.sync.set({"fullscreenweb":$('fullscreenweb').checked,"fullscreenwindow":$('fullscreenwindow').checked,"fullscreenvideo":$('fullscreenvideo').checked,"videoinwindow":$('videoinwindow').checked,"videooutwindow":$('videooutwindow').checked});
}

document.addEventListener('DOMContentLoaded', function(){
    chrome.storage.sync.get(['darkmode','firstDate','optionskipremember','firstsawrate','fullscreenweb','fullscreenwindow','fullscreenvideo','videoinwindow','videooutwindow'], function(items){
        darkmode = items['darkmode'];if(darkmode == null)darkmode = false; // default false
        fullscreenweb = items['fullscreenweb'];if(fullscreenweb == null)fullscreenweb = false; // default true
        fullscreenwindow = items['fullscreenwindow'];if(fullscreenwindow == null)fullscreenwindow = false; // default false
        fullscreenvideo = items['fullscreenvideo'];if(fullscreenvideo == null)fullscreenvideo = false; // default false
        videoinwindow = items['videoinwindow'];if(videoinwindow == null)videoinwindow = true; // default true
        videooutwindow = items['videooutwindow'];if(videooutwindow == null)videooutwindow = false; // default false

        if(fullscreenweb == true)$('fullscreenweb').checked = true;
        if(fullscreenwindow == true)$('fullscreenwindow').checked = true;
        if(fullscreenvideo == true)$('fullscreenvideo').checked = true;
        if(videoinwindow == true)$('videoinwindow').checked = true;
        if(videooutwindow == true)$('videooutwindow').checked = true;

        // dark mode
        if(darkmode == true){
            document.body.className = 'dark';
        } else{
            document.body.className = 'light';
        }

        if(optionskipremember){optionskipremember = items['optionskipremember'];}
        if(firstDate){firstDate = items['firstDate'];}
        if(firstsawrate){firstsawrate = items['firstsawrate'];}

        // final
        test();

        // show remember page
        var firstmonth = false;
        var currentDate = new Date().getTime();
        if(firstDate){
            var datestart = firstDate;
            var dateend = datestart + (30 * 24 * 60 * 60 * 1000);
            if(currentDate>=dateend){firstmonth = false;}
            else{firstmonth = true;}
        }else{
            chrome.storage.sync.set({"firstDate": currentDate});
            firstmonth = true;
        }

        if(firstmonth){
        // show nothing
        }else{
            if(optionskipremember != true){
                if(firstsawrate != true){
                    materialRateAlert(function(result){console.log(result)})
                    chrome.storage.sync.set({"firstsawrate": true});
                }
            }
        }
    });

    // Detect click / change to save the page and test it.
    var inputs = document.querySelectorAll('input');
    var i;
    var l = inputs.length;
    for(i = 0; i < l; i++){inputs[i].addEventListener('change', test);inputs[i].addEventListener('change', save_options);}

    $("tab1").addEventListener('click', function(){
        $("basicspanel").className = "";
        $("morepanel").className = "hidden";

        $("tab1").className = "tabbutton tabhighlight";
        $("tab2").className = "tabbutton";
    },false);

    $("tab2").addEventListener('click', function(){
        $("basicspanel").className = "hidden";
        $("morepanel").className = "";

        $("tab1").className = "tabbutton";
        $("tab2").className = "tabbutton tabhighlight";
    },false);

    $("btncurrentmaximize").addEventListener('click', function(){
        chrome.runtime.sendMessage({name: 'sendcurrentmaximize'});
    });
    $("btnallmaximize").addEventListener('click', function(){
        chrome.runtime.sendMessage({name: 'sendallmaximize'});
    });
    $("btncurrentfullscreen").addEventListener('click', function(){
        chrome.runtime.sendMessage({name: 'sendcurrentfullscreen'});
    });
    $("btnallfullscreen").addEventListener('click', function(){
        chrome.runtime.sendMessage({name: 'sendallfullscreen'});
    });

    $("btnoptions").addEventListener('click', function(){chrome.tabs.create({url: chrome.extension.getURL('options.html'), active:true})});
    $("btndonate").addEventListener('click', function(){chrome.tabs.create({url: donatewebsite, active:true})});

    // date today
    var today = new Date();
    var dd = today.getDate();
    var mm = today.getMonth()+1; //January is 0!

    var yyyy = today.getFullYear();
    if(dd<10){dd='0'+dd;}
    if(mm<10){mm='0'+mm;}
    var today = dd+'/'+mm+'/'+yyyy;

    // rate
    function materialRateAlert(callback){
        document.getElementById('materialModalRate').className = 'show';
        document.getElementById('materialModalRate').setAttribute('aria-disabled', "false");   
    }
    function closeMaterialRateAlert(e, result){
        e.stopPropagation();
        document.getElementById('materialModalRate').className = 'hide';
        document.getElementById('materialModalRate').setAttribute('aria-disabled', "true");   
    }

    $("materialModalRateButtonOK").addEventListener('click', function(e){
        closeMaterialRateAlert(e, true);
        window.open(writereview);chrome.storage.sync.set({"reviewedlastonversion": chrome.runtime.getManifest().version});
    });
    $("materialModalRateButtonCANCEL").addEventListener('click', function(e){
        closeMaterialRateAlert(e, false);
        chrome.storage.sync.set({"firstsawrate": false});
    });
});

chrome.storage.onChanged.addListener(function(changes, namespace){
        if(changes['atmosvivid']){
            if(changes['atmosvivid'].newValue == true){
                chrome.tabs.query({},function(tabs){
                    tabs.forEach(function(tab){
                      chrome.tabs.sendMessage(tab.id, { action: "goenableatmos" });
                    });
                });
            }else{
                chrome.tabs.query({},function(tabs){
                    tabs.forEach(function(tab){
                      chrome.tabs.sendMessage(tab.id, { action: "goenableatmos" });
                    });
                });
            }
        }
 })

function test(){
}